# SAHIHI — Prototype

Reduces manual mark-entry errors by connecting scanned mark sheets directly
to verified student records, with automated, school-configurable results
processing. **V2** adds two things V1 didn't have: assessment components
(Sequence 1, Sequence 2, Exam...) as separate, combinable marks, and a
full admin-only "School Configuration" section so a non-technical admin
can set up a school's academic structure, subjects, assessment components,
and grading scale without touching the database.

This is the Phase 1–9 MVP: **scan → recognize → verify → save → calculate
→ generate report card.**

## Quick start

```bash
pip3 install -r requirements.txt --break-system-packages   # if not already installed
python3 seed_data.py                  # creates instance/sahihi.db with 1 example school + 25 students
python3 generate_sample_marksheet.py  # creates a demo mark sheet to scan (uploads/demo_marksheet_mathematics.png)
python3 app.py                        # runs on http://localhost:5050
```

Login as `teacher1` / `teacher123` (or `admin1` / `admin123`).

Run the automated tests any time with:
```bash
python3 -m unittest test_sahihi -v
```

## 5–10 minute demo script

1. Log in as `teacher1`.
2. Dashboard shows the one example school's classes/subjects/terms/**assessment components**.
3. **Scan a mark sheet** → select Form 3A / Mathematics / Term 1 / **Sequence 1** →
   upload `uploads/demo_marksheet_mathematics.png` (or print it and photograph
   it — it's a real, scannable page).
4. You land on the **verification screen**. Notice:
   - ST010's mark is flagged low-confidence (it was printed faint on purpose)
   - ST015 shows "Missing mark" (left blank on purpose)
   - ST099 shows "ID not found" (not a real student, on purpose)
   - Nothing here is saved yet — you must Confirm/Edit/Reject each row.
5. Confirm the clean rows, edit the faint one after checking the photo,
   reject the unmatched ones, then click **Finalize**.
6. **Scan a second mark sheet** for the *same* class/subject/term but choose
   **Sequence 2** this time — this proves the two are stored as genuinely
   separate marks, not one overwriting the other.
7. Go to **Results** → pick Form 3A / Term 1 → see the ranked list, computed
   from the *combined* Sequence 1 + Sequence 2 scores.
8. Click **Download PDF** on any student → a report card showing each
   assessment component's raw mark side-by-side with the derived term score.
9. Log in as `admin1` → **Admin** in the nav → **Assessment components** →
   add a new one (e.g. "Project") → log back in as `teacher1` → it
   immediately appears as a scan option. Nothing about components is
   hard-coded.
10. To prove school customization further: open `test_sahihi.py`'s
    `test_configurable_scales_are_independent` — two schools, same 55%
    score, different grade letters, because grading rules live in the
    database, not in code.

## Architecture

```
app.py            Flask routes: auth, scan/verify/finalize, results, report_card, admin/*
db.py             all SQL lives here; per-request connection via flask.g
schema.sql        full database schema (schools, assessment_components, marks, audit_log...)
ocr.py            image -> rows of (student_id, name, mark, confidence)
grading.py        configurable grading engine — combines assessment components into a term score
report.py         PDF report card generation (ReportLab) — shows the component breakdown
seed_data.py       creates the one example school + 25 students + 3 assessment components
generate_sample_marksheet.py   builds a demo/test mark-sheet image
test_sahihi.py     automated tests (Phase 9) — 17 tests covering grading, OCR, web flow, admin
templates/, static/  the UI
templates/admin/     the School Configuration section (admin-only)
```

**Data flow:** a photo becomes a `mark_sheets` row (scoped to one class +
subject + term + **assessment component**), OCR output becomes
`detected_rows` (nothing official yet), teacher review turns each row into
`confirmed`/`edited`/`rejected`, and only on **Finalize** do confirmed rows
become real `marks` — one row per student/subject/term/component. A
subject's term score is never stored directly: `grading.compute_subject_term_score()`
derives it fresh every time from whichever components have marks recorded,
normalized onto the school's scale and combined by each component's weight.
Every overwrite of an existing mark, and every admin edit to school info or
subject coefficients, is written to `audit_log` with old value, new value,
who, and when.

## School Configuration (admin-only)

Everything under **Admin** in the nav (visible only to the `admin` role) is
real, working CRUD against the database — not a mockup:
- **School information** — name, logo, address, contact info, marks scale,
  pass mark, ranking on/off, plus starting new academic years
- **Terms**, **Classes**, **Subjects** (with coefficient) — add/edit/delete
- **Assessment components** — add/edit/deactivate/delete; each has a name,
  optional code, weight, and its own max_score (so an Exam out of 100 and
  Sequences out of 20 can coexist and still combine correctly)
- **Grading scale** — the score bands that map to grade letters

Add a component here and it's immediately available on the teacher's scan
page — nothing requires a code change or restart.

## Why these technology choices

| Layer | Choice | Why |
|---|---|---|
| Frontend | Flask/Jinja2 + vanilla JS | No build step, works on any phone browser, easy for a beginner to debug |
| Backend | Flask (Python) | Simple, huge docs, easy to reason about |
| Database | SQLite | Zero setup; same SQL mostly carries over to Postgres later |
| Auth | Flask sessions + Werkzeug password hashing | No external service needed for a prototype |
| OCR | Tesseract (local) | Free, no network dependency, good enough to prove the pipeline on printed/clear text |
| Report cards | ReportLab | Generates real, professional PDFs |
| Image storage | local `uploads/` folder | Simplest possible for a prototype |

## OCR: what's real here vs. production

This prototype uses **local Tesseract OCR**, which is free and requires no
internet — but it is genuinely weak on handwriting. It's used here to prove
the *pipeline* (detect → flag confidence → force human confirmation) is
correct end-to-end, not to prove OCR accuracy on handwriting.

**For production, replace `ocr.extract_rows()`'s implementation with a call
to Google Cloud Vision / Document AI** (best handwriting accuracy of the
options compared, pay-per-use, straightforward REST API) — or Azure
Document Intelligence as a close second. Nothing else changes: every other
module only calls `ocr.extract_rows()`, never Tesseract directly, so this
is a one-file swap. **What would cost money in real deployment:** the
per-page OCR API calls (~$1.50 per 1,000 pages on Google Cloud Vision at
time of writing — verify current pricing before committing), and cloud
image storage if you move off local disk.

The confirmation step (Phase 4) is architecturally mandatory regardless of
which OCR engine is used — the app never auto-saves a detected value.

## Security & audit trail

- Passwords hashed with Werkzeug (never stored plain).
- Two roles: `teacher` (scan/confirm) and `admin` (same, prototype doesn't
  yet split further — see "Later" list).
- Every time an *existing* official mark is overwritten, `audit_log` records
  old value, new value, who, when, and a reason string.
- **Before real deployment:** change `app.secret_key` in `app.py` to a real
  secret loaded from an environment variable, put the app behind HTTPS, and
  add rate-limiting on `/login`.

## Offline considerations

The prototype requires connectivity (it's a normal web app). For a
production version supporting unreliable connectivity:
- The scan capture step would run as a PWA or native app that stores photos
  + form selections locally (IndexedDB/SQLite on-device) when offline.
- A sync queue would upload pending mark sheets when connectivity returns,
  reusing the exact same `image_hash` duplicate-detection this prototype
  already has.
- OCR itself would still need to run server-side (or via an on-device model,
  a larger undertaking) once connectivity is available — the phone doesn't
  need to be online *while scanning*, only to eventually sync.

## Error handling implemented

Duplicate mark-sheet upload (same image hash) · student ID not found ·
detected name doesn't match matched student · invalid/out-of-range mark ·
missing mark · unrecognized image / no rows detected · unsupported file
type. See `test_sahihi.py` for the automated cases and section 9 of the
original spec for the full checklist.

## Later / Production version (deliberately out of scope for this MVP)

- QR/barcode on the mark sheet as a backup ID reader (reportlab supports
  generating Code128 barcodes; pair with a `pyzbar`-based reader server-side)
- Full offline capture + sync queue (see above)
- Finer-grained admin permissions (e.g. admin approval required before an
  audit-logged correction takes effect)
- Multi-school admin UI for configuring grading scales/subjects through the
  browser instead of directly in the database
- Real cloud OCR integration (Google Cloud Vision / Document AI)
- Cloud image storage (S3-compatible) instead of local disk
- Production WSGI server (gunicorn) + real secret management
- Configurable report-card template per school (currently one fixed layout)
