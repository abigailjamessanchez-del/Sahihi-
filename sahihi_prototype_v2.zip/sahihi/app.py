"""
app.py — SAHIHI prototype web application.

Flow implemented end-to-end (Phases 2-7):
  login -> select class/subject/term -> upload mark sheet -> OCR extraction
  -> teacher verification screen -> confirm/save -> marks stored
  -> calculations (grading.py) -> report card PDF (report.py)

Kept in one file on purpose for a beginner-friendly prototype: every route
is easy to find. If this grows past ~500 lines, split into blueprints.
"""
import os
from functools import wraps
from flask import (Flask, request, redirect, url_for, session, render_template,
                    flash, send_file, jsonify, abort)
from werkzeug.security import check_password_hash
from werkzeug.utils import secure_filename

from db import get_db, init_db, log_audit, close_db
import ocr
import grading
import report

app = Flask(__name__)
app.secret_key = "dev-secret-key-change-in-production"  # see README: must be a real secret in prod
app.teardown_appcontext(close_db)  # ensures every request's DB connection is closed, not leaked

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg"}


# ---------------------------------------------------------------- helpers
def login_required(role=None):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                abort(403)
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# ------------------------------------------------------------------ auth
@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("dashboard") if "user_id" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["school_id"] = user["school_id"]
            session["role"] = user["role"]
            session["full_name"] = user["full_name"]
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ------------------------------------------------------------- dashboard
@app.route("/dashboard")
@login_required()
def dashboard():
    conn = get_db()
    school_id = session["school_id"]
    classes = conn.execute("SELECT * FROM classes WHERE school_id = ?", (school_id,)).fetchall()
    subjects = conn.execute("SELECT * FROM subjects WHERE school_id = ?", (school_id,)).fetchall()
    terms = conn.execute(
        "SELECT t.*, y.label AS year_label FROM terms t "
        "JOIN academic_years y ON y.id = t.academic_year_id WHERE t.school_id = ?",
        (school_id,),
    ).fetchall()
    components = conn.execute(
        "SELECT * FROM assessment_components WHERE school_id = ? AND is_active = 1 ORDER BY order_index",
        (school_id,),
    ).fetchall()
    recent_sheets = conn.execute(
        "SELECT ms.*, c.name AS class_name, s.name AS subject_name, ac.name AS component_name "
        "FROM mark_sheets ms "
        "JOIN classes c ON c.id = ms.class_id JOIN subjects s ON s.id = ms.subject_id "
        "JOIN assessment_components ac ON ac.id = ms.assessment_component_id "
        "WHERE ms.school_id = ? ORDER BY ms.id DESC LIMIT 10",
        (school_id,),
    ).fetchall()
    return render_template("dashboard.html", classes=classes, subjects=subjects,
                            terms=terms, components=components, recent_sheets=recent_sheets)


# ------------------------------------------------------ scan / OCR / save
@app.route("/scan", methods=["GET", "POST"])
@login_required()
def scan():
    conn = get_db()
    school_id = session["school_id"]

    if request.method == "GET":
        classes = conn.execute("SELECT * FROM classes WHERE school_id = ?", (school_id,)).fetchall()
        subjects = conn.execute("SELECT * FROM subjects WHERE school_id = ?", (school_id,)).fetchall()
        terms = conn.execute("SELECT * FROM terms WHERE school_id = ?", (school_id,)).fetchall()
        components = conn.execute(
            "SELECT * FROM assessment_components WHERE school_id = ? AND is_active = 1 ORDER BY order_index",
            (school_id,),
        ).fetchall()
        if not components:
            flash("No assessment components are configured yet. Ask an admin to set up "
                  "Assessment Components (e.g. Sequence 1, Exam) before scanning.")
        return render_template("scan.html", classes=classes, subjects=subjects, terms=terms,
                                components=components)

    # POST: an image was uploaded
    class_id = request.form.get("class_id", type=int)
    subject_id = request.form.get("subject_id", type=int)
    term_id = request.form.get("term_id", type=int)
    component_id = request.form.get("assessment_component_id", type=int)
    file = request.files.get("marksheet_image")

    if not (class_id and subject_id and term_id and component_id):
        flash("Please select class, subject, term and assessment component before scanning.")
        return redirect(url_for("scan"))
    if not file or file.filename == "":
        flash("Please choose a mark sheet image.")
        return redirect(url_for("scan"))
    if not allowed_file(file.filename):
        flash("Unsupported file type. Please upload a PNG or JPG image.")
        return redirect(url_for("scan"))

    filename = secure_filename(f"{session['user_id']}_{class_id}_{subject_id}_{term_id}_{component_id}_{file.filename}")
    save_path = os.path.join(UPLOAD_DIR, filename)
    file.save(save_path)

    # --- duplicate upload detection (spec section 9) -----------------
    img_hash = ocr.file_hash(save_path)
    dup = conn.execute(
        "SELECT id FROM mark_sheets WHERE image_hash = ? AND class_id = ? AND subject_id = ? "
        "AND term_id = ? AND assessment_component_id = ?",
        (img_hash, class_id, subject_id, term_id, component_id),
    ).fetchone()
    if dup:
        flash(f"This exact mark sheet was already uploaded (mark sheet #{dup['id']}). "
              f"Upload skipped to avoid duplicate marks.")
        return redirect(url_for("scan"))

    school = conn.execute("SELECT * FROM schools WHERE id = ?", (school_id,)).fetchone()
    component = conn.execute("SELECT * FROM assessment_components WHERE id = ? AND school_id = ?",
                              (component_id, school_id)).fetchone()
    if not component:
        flash("Unknown assessment component.")
        return redirect(url_for("scan"))

    try:
        rows = ocr.extract_rows(save_path, max_score=component["max_score"])
    except Exception as e:
        flash(f"Could not process this image: {e}. Please try a clearer photo.")
        return redirect(url_for("scan"))

    if not rows:
        flash("No recognizable rows were found on this mark sheet. "
              "Check the photo is well-lit, in focus, and not cropped.")
        return redirect(url_for("scan"))

    sheet_id = conn.execute(
        "INSERT INTO mark_sheets (school_id, class_id, subject_id, term_id, assessment_component_id, "
        "teacher_id, image_path, image_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (school_id, class_id, subject_id, term_id, component_id, session["user_id"], save_path, img_hash),
    ).lastrowid

    # Match every detected row against real students and flag problems.
    # We NEVER auto-save here — everything lands in detected_rows as 'pending'.
    class_students = {s["student_code"]: s for s in
                       conn.execute("SELECT * FROM students WHERE class_id = ?", (class_id,)).fetchall()}

    for r in rows:
        student = class_students.get(r["student_code"])
        match_status = "ok"
        matched_student_id = None
        mark_value = None

        if student is None:
            match_status = "id_not_found"
        else:
            matched_student_id = student["id"]
            if r["name"] and student["full_name"].split()[0].lower() not in r["name"].lower():
                match_status = "name_mismatch"

        if r["mark"] is None:
            match_status = "missing_mark"
        else:
            try:
                mark_value = float(r["mark"])
                if mark_value < 0 or mark_value > component["max_score"]:
                    match_status = "invalid_mark"
            except ValueError:
                match_status = "invalid_mark"
                mark_value = None

        conn.execute(
            "INSERT INTO detected_rows (mark_sheet_id, row_number, detected_student_code, detected_name, "
            "detected_mark, confidence, matched_student_id, match_status, final_student_id, final_mark) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (sheet_id, r["row_number"], r["student_code"], r["name"], r["mark"], r["confidence"],
             matched_student_id, match_status, matched_student_id, mark_value),
        )
    conn.commit()
    return redirect(url_for("verify", sheet_id=sheet_id))


@app.route("/verify/<int:sheet_id>", methods=["GET"])
@login_required()
def verify(sheet_id):
    conn = get_db()
    sheet = conn.execute(
        "SELECT ms.*, c.name AS class_name, s.name AS subject_name, t.name AS term_name, "
        "ac.name AS component_name, ac.max_score AS component_max_score "
        "FROM mark_sheets ms JOIN classes c ON c.id = ms.class_id "
        "JOIN subjects s ON s.id = ms.subject_id JOIN terms t ON t.id = ms.term_id "
        "JOIN assessment_components ac ON ac.id = ms.assessment_component_id "
        "WHERE ms.id = ? AND ms.school_id = ?",
        (sheet_id, session["school_id"]),
    ).fetchone()
    if not sheet:
        abort(404)

    rows = conn.execute(
        "SELECT * FROM detected_rows WHERE mark_sheet_id = ? ORDER BY row_number", (sheet_id,)
    ).fetchall()
    students = conn.execute(
        "SELECT id, student_code, full_name FROM students WHERE class_id = ?", (sheet["class_id"],)
    ).fetchall()
    return render_template("verify.html", sheet=sheet, rows=rows, students=students,
                            low_conf_threshold=ocr.LOW_CONFIDENCE_THRESHOLD)


@app.route("/verify/<int:sheet_id>/row/<int:row_id>", methods=["POST"])
@login_required()
def update_row(sheet_id, row_id):
    """
    Teacher edits or confirms a single detected row. This is the mandatory
    human-in-the-loop step — nothing here is auto-accepted (spec section 7).
    """
    conn = get_db()
    action = request.form.get("action")  # 'confirm' or 'edit'
    student_id = request.form.get("student_id", type=int)
    mark = request.form.get("mark", type=float)

    row = conn.execute("SELECT * FROM detected_rows WHERE id = ? AND mark_sheet_id = ?",
                        (row_id, sheet_id)).fetchone()
    if not row:
        abort(404)

    sheet = conn.execute("SELECT ms.*, ac.max_score AS component_max_score FROM mark_sheets ms "
                          "JOIN assessment_components ac ON ac.id = ms.assessment_component_id "
                          "WHERE ms.id = ?", (sheet_id,)).fetchone()

    if action == "reject":
        conn.execute("UPDATE detected_rows SET review_status = 'rejected', reviewed_by = ?, reviewed_at = datetime('now') "
                     "WHERE id = ?", (session["user_id"], row_id))
        conn.commit()
        return jsonify({"ok": True, "status": "rejected"})

    if not student_id:
        return jsonify({"ok": False, "error": "A valid student must be selected."}), 400
    if mark is None or mark < 0 or mark > sheet["component_max_score"]:
        return jsonify({"ok": False, "error": f"Mark must be between 0 and {sheet['component_max_score']:.0f}."}), 400

    new_status = "confirmed" if action == "confirm" else "edited"
    conn.execute(
        "UPDATE detected_rows SET final_student_id = ?, final_mark = ?, review_status = ?, "
        "reviewed_by = ?, reviewed_at = datetime('now') WHERE id = ?",
        (student_id, mark, new_status, session["user_id"], row_id),
    )
    conn.commit()
    return jsonify({"ok": True, "status": new_status})


@app.route("/verify/<int:sheet_id>/finalize", methods=["POST"])
@login_required()
def finalize_sheet(sheet_id):
    """
    Writes every confirmed/edited row into the official `marks` table.
    Rows still 'pending' or 'rejected' are skipped and reported back,
    so the teacher can see exactly what was and wasn't saved.
    """
    conn = get_db()
    sheet = conn.execute("SELECT * FROM mark_sheets WHERE id = ? AND school_id = ?",
                          (sheet_id, session["school_id"])).fetchone()
    if not sheet:
        abort(404)

    rows = conn.execute("SELECT * FROM detected_rows WHERE mark_sheet_id = ?", (sheet_id,)).fetchall()

    saved, skipped = 0, 0
    for row in rows:
        if row["review_status"] not in ("confirmed", "edited"):
            skipped += 1
            continue
        # UPSERT: one official mark per student/subject/term/component (spec: only confirmed marks saved)
        existing = conn.execute(
            "SELECT * FROM marks WHERE student_id = ? AND subject_id = ? AND term_id = ? "
            "AND assessment_component_id = ?",
            (row["final_student_id"], sheet["subject_id"], sheet["term_id"], sheet["assessment_component_id"]),
        ).fetchone()
        if existing:
            log_audit(conn, "marks", existing["id"], "score", existing["score"], row["final_mark"],
                      session["user_id"], reason="Re-scanned mark sheet")
            conn.execute("UPDATE marks SET score = ?, entered_by = ?, entered_at = datetime('now'), "
                         "source_mark_sheet_id = ?, source_detected_row_id = ? WHERE id = ?",
                         (row["final_mark"], session["user_id"], sheet_id, row["id"], existing["id"]))
        else:
            conn.execute(
                "INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                "source_mark_sheet_id, source_detected_row_id, entered_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (row["final_student_id"], sheet["subject_id"], sheet["term_id"], sheet["assessment_component_id"],
                 row["final_mark"], sheet_id, row["id"], session["user_id"]),
            )
        saved += 1

    conn.execute("UPDATE mark_sheets SET status = 'saved' WHERE id = ?", (sheet_id,))
    conn.commit()
    flash(f"{saved} marks saved to student records. {skipped} row(s) skipped (not confirmed).")
    return redirect(url_for("class_results", class_id=sheet["class_id"], term_id=sheet["term_id"]))


# --------------------------------------------------------- results/report
@app.route("/results")
@login_required()
def class_results():
    conn = get_db()
    class_id = request.args.get("class_id", type=int)
    term_id = request.args.get("term_id", type=int)
    school_id = session["school_id"]

    classes = conn.execute("SELECT * FROM classes WHERE school_id = ?", (school_id,)).fetchall()
    terms = conn.execute("SELECT * FROM terms WHERE school_id = ?", (school_id,)).fetchall()

    ranking = []
    if class_id and term_id:
        ranking = grading.compute_class_ranking(conn, school_id, class_id, term_id)

    return render_template("results.html", classes=classes, terms=terms, ranking=ranking,
                            selected_class=class_id, selected_term=term_id)


@app.route("/report_card/<int:student_id>/<int:term_id>")
@login_required()
def report_card(student_id, term_id):
    conn = get_db()
    student = conn.execute("SELECT * FROM students WHERE id = ? AND school_id = ?",
                            (student_id, session["school_id"])).fetchone()
    if not student:
        abort(404)
    path = report.generate_report_card(conn, session["school_id"], student_id, term_id)
    if not path:
        flash("This student has no marks recorded for that term yet.")
        return redirect(url_for("class_results"))
    return send_file(path, as_attachment=True, download_name=os.path.basename(path))


# ============================================================ ADMIN AREA
# "School Configuration" — spec section 3. Admin-only. One core codebase,
# every school's academic structure, grading rules, and assessment
# components are all data configured here, never hard-coded.
LOGO_DIR = os.path.join(UPLOAD_DIR, "logos")
os.makedirs(LOGO_DIR, exist_ok=True)


@app.route("/admin")
@login_required(role="admin")
def admin_index():
    return render_template("admin/index.html")


@app.route("/admin/school", methods=["GET", "POST"])
@login_required(role="admin")
def admin_school():
    conn = get_db()
    school_id = session["school_id"]

    if request.method == "POST":
        form = request.form
        school = conn.execute("SELECT * FROM schools WHERE id = ?", (school_id,)).fetchone()

        logo_path = school["logo_path"]
        logo_file = request.files.get("logo")
        if logo_file and logo_file.filename and allowed_file(logo_file.filename):
            fname = secure_filename(f"school_{school_id}_{logo_file.filename}")
            full_path = os.path.join(LOGO_DIR, fname)
            logo_file.save(full_path)
            logo_path = full_path

        for field, value in [("name", form.get("name", "").strip()),
                              ("address", form.get("address", "").strip()),
                              ("contact_info", form.get("contact_info", "").strip())]:
            if value != (school[field] or ""):
                log_audit(conn, "schools", school_id, field, school[field], value, session["user_id"])

        max_score = form.get("max_score", type=float) or school["max_score"]
        pass_mark = form.get("pass_mark", type=float) or school["pass_mark"]
        ranking_enabled = 1 if form.get("ranking_enabled") == "on" else 0

        conn.execute(
            "UPDATE schools SET name=?, address=?, contact_info=?, logo_path=?, max_score=?, "
            "pass_mark=?, ranking_enabled=? WHERE id=?",
            (form.get("name", "").strip(), form.get("address", "").strip(), form.get("contact_info", "").strip(),
             logo_path, max_score, pass_mark, ranking_enabled, school_id),
        )

        new_year_label = form.get("new_academic_year", "").strip()
        if new_year_label:
            conn.execute("INSERT INTO academic_years (school_id, label) VALUES (?, ?)",
                         (school_id, new_year_label))

        conn.commit()
        flash("School configuration updated.")
        return redirect(url_for("admin_school"))

    school = conn.execute("SELECT * FROM schools WHERE id = ?", (school_id,)).fetchone()
    years = conn.execute("SELECT * FROM academic_years WHERE school_id = ? ORDER BY id DESC",
                          (school_id,)).fetchall()
    return render_template("admin/school.html", school=school, years=years)


@app.route("/admin/terms", methods=["GET", "POST"])
@login_required(role="admin")
def admin_terms():
    conn = get_db()
    school_id = session["school_id"]

    if request.method == "POST":
        if request.form.get("_action") == "delete":
            row_id = request.form.get("row_id", type=int)
            try:
                conn.execute("DELETE FROM terms WHERE id = ? AND school_id = ?", (row_id, school_id))
                conn.commit()
                flash("Term deleted.")
            except Exception:
                flash("Could not delete — this term already has marks recorded against it.")
        else:
            name = request.form.get("name", "").strip()
            year_id = request.form.get("academic_year_id", type=int)
            if not name or not year_id:
                flash("Term name and academic year are required.")
            else:
                conn.execute("INSERT INTO terms (school_id, academic_year_id, name) VALUES (?, ?, ?)",
                             (school_id, year_id, name))
                conn.commit()
                flash("Term added.")
        return redirect(url_for("admin_terms"))

    terms = conn.execute(
        "SELECT t.*, y.label AS year_label FROM terms t JOIN academic_years y ON y.id = t.academic_year_id "
        "WHERE t.school_id = ? ORDER BY t.id", (school_id,)).fetchall()
    years = conn.execute("SELECT * FROM academic_years WHERE school_id = ? ORDER BY id DESC", (school_id,)).fetchall()
    return render_template("admin/terms.html", terms=terms, years=years)


@app.route("/admin/classes", methods=["GET", "POST"])
@login_required(role="admin")
def admin_classes():
    conn = get_db()
    school_id = session["school_id"]

    if request.method == "POST":
        if request.form.get("_action") == "delete":
            row_id = request.form.get("row_id", type=int)
            try:
                conn.execute("DELETE FROM classes WHERE id = ? AND school_id = ?", (row_id, school_id))
                conn.commit()
                flash("Class deleted.")
            except Exception:
                flash("Could not delete — this class already has students assigned.")
        else:
            name = request.form.get("name", "").strip()
            if not name:
                flash("Class name is required.")
            else:
                conn.execute("INSERT INTO classes (school_id, name) VALUES (?, ?)", (school_id, name))
                conn.commit()
                flash("Class added.")
        return redirect(url_for("admin_classes"))

    classes = conn.execute("SELECT * FROM classes WHERE school_id = ? ORDER BY id", (school_id,)).fetchall()
    return render_template("admin/classes.html", classes=classes)


@app.route("/admin/subjects", methods=["GET", "POST"])
@login_required(role="admin")
def admin_subjects():
    conn = get_db()
    school_id = session["school_id"]

    if request.method == "POST":
        if request.form.get("_action") == "delete":
            row_id = request.form.get("row_id", type=int)
            try:
                conn.execute("DELETE FROM subjects WHERE id = ? AND school_id = ?", (row_id, school_id))
                conn.commit()
                flash("Subject deleted.")
            except Exception:
                flash("Could not delete — this subject already has marks recorded against it.")
        elif request.form.get("_action") == "update":
            row_id = request.form.get("row_id", type=int)
            coefficient = request.form.get("coefficient", type=float)
            existing = conn.execute("SELECT * FROM subjects WHERE id = ?", (row_id,)).fetchone()
            if existing and coefficient is not None:
                log_audit(conn, "subjects", row_id, "coefficient", existing["coefficient"], coefficient,
                          session["user_id"], reason="Admin edit via School Configuration")
                conn.execute("UPDATE subjects SET coefficient = ? WHERE id = ? AND school_id = ?",
                             (coefficient, row_id, school_id))
                conn.commit()
                flash("Subject updated.")
        else:
            name = request.form.get("name", "").strip()
            code = request.form.get("code", "").strip()
            coefficient = request.form.get("coefficient", type=float) or 1
            if not name:
                flash("Subject name is required.")
            else:
                conn.execute("INSERT INTO subjects (school_id, name, code, coefficient) VALUES (?, ?, ?, ?)",
                             (school_id, name, code, coefficient))
                conn.commit()
                flash("Subject added.")
        return redirect(url_for("admin_subjects"))

    subjects = conn.execute("SELECT * FROM subjects WHERE school_id = ? ORDER BY id", (school_id,)).fetchall()
    return render_template("admin/subjects.html", subjects=subjects)


@app.route("/admin/components", methods=["GET", "POST"])
@login_required(role="admin")
def admin_components():
    """
    Assessment Components — spec section 3D. This is the screen that
    replaces hard-coded "Sequence 1"/"Sequence 2": the admin defines
    whatever components this school actually uses, each with a weight
    (how much it counts toward the term score) and its own max_score.
    """
    conn = get_db()
    school_id = session["school_id"]

    if request.method == "POST":
        if request.form.get("_action") == "delete":
            row_id = request.form.get("row_id", type=int)
            try:
                conn.execute("DELETE FROM assessment_components WHERE id = ? AND school_id = ?",
                             (row_id, school_id))
                conn.commit()
                flash("Assessment component deleted.")
            except Exception:
                flash("Could not delete — marks already recorded against this component. "
                      "You can deactivate it instead by setting it inactive.")
        elif request.form.get("_action") == "toggle_active":
            row_id = request.form.get("row_id", type=int)
            row = conn.execute("SELECT * FROM assessment_components WHERE id = ?", (row_id,)).fetchone()
            if row:
                conn.execute("UPDATE assessment_components SET is_active = ? WHERE id = ? AND school_id = ?",
                             (0 if row["is_active"] else 1, row_id, school_id))
                conn.commit()
        elif request.form.get("_action") == "update":
            row_id = request.form.get("row_id", type=int)
            weight = request.form.get("weight", type=float)
            max_score = request.form.get("max_score", type=float)
            if weight is not None and max_score is not None:
                conn.execute("UPDATE assessment_components SET weight = ?, max_score = ? "
                             "WHERE id = ? AND school_id = ?", (weight, max_score, row_id, school_id))
                conn.commit()
                flash("Assessment component updated.")
        else:
            name = request.form.get("name", "").strip()
            code = request.form.get("code", "").strip()
            weight = request.form.get("weight", type=float) or 1
            max_score = request.form.get("max_score", type=float) or 20
            if not name:
                flash("Component name is required.")
            else:
                max_order = conn.execute(
                    "SELECT COALESCE(MAX(order_index), 0) AS m FROM assessment_components WHERE school_id = ?",
                    (school_id,)).fetchone()["m"]
                conn.execute(
                    "INSERT INTO assessment_components (school_id, name, code, weight, max_score, order_index) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (school_id, name, code, weight, max_score, max_order + 1))
                conn.commit()
                flash(f"Assessment component '{name}' added.")
        return redirect(url_for("admin_components"))

    components = conn.execute("SELECT * FROM assessment_components WHERE school_id = ? ORDER BY order_index",
                               (school_id,)).fetchall()
    return render_template("admin/components.html", components=components)


@app.route("/admin/grading", methods=["GET", "POST"])
@login_required(role="admin")
def admin_grading():
    conn = get_db()
    school_id = session["school_id"]

    if request.method == "POST":
        if request.form.get("_action") == "delete":
            row_id = request.form.get("row_id", type=int)
            conn.execute("DELETE FROM grading_scales WHERE id = ? AND school_id = ?", (row_id, school_id))
            conn.commit()
            flash("Grade band deleted.")
        else:
            min_score = request.form.get("min_score", type=float)
            max_score = request.form.get("max_score", type=float)
            letter = request.form.get("grade_letter", "").strip()
            remark = request.form.get("remark", "").strip()
            if min_score is None or max_score is None or not letter:
                flash("Min score, max score and grade letter are all required.")
            else:
                conn.execute(
                    "INSERT INTO grading_scales (school_id, min_score, max_score, grade_letter, remark) "
                    "VALUES (?, ?, ?, ?, ?)", (school_id, min_score, max_score, letter, remark))
                conn.commit()
                flash("Grade band added.")
        return redirect(url_for("admin_grading"))

    bands = conn.execute("SELECT * FROM grading_scales WHERE school_id = ? ORDER BY min_score DESC",
                          (school_id,)).fetchall()
    return render_template("admin/grading.html", bands=bands)


if __name__ == "__main__":
    if not os.path.exists(os.path.join("instance", "sahihi.db")):
        init_db()
    app.run(host="0.0.0.0", port=5050, debug=True)
