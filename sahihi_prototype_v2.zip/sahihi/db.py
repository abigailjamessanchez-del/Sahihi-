"""
db.py — all raw database access lives here.

Why a separate file: keeping every SQL statement in one place means when
something breaks, you only need to look in one file to find the query
that's misbehaving, instead of hunting through route handlers.
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "instance", "sahihi.db")

try:
    # Flask's application-context storage. When running outside a Flask
    # request (seed scripts, tests without an app context), flask.g is
    # unavailable, so every caller falls back to a plain unmanaged connection.
    from flask import g, has_app_context
except ImportError:  # pragma: no cover
    g = None
    def has_app_context():
        return False


def get_db():
    """
    Returns one SQLite connection per request when called inside a Flask
    request (cached on flask.g, closed automatically by close_db below —
    see app.py's teardown_appcontext registration). Outside a request
    (scripts, tests) it just returns a fresh connection the caller is
    responsible for closing.
    """
    if has_app_context():
        if "db_conn" not in g:
            g.db_conn = _connect()
        return g.db_conn
    return _connect()


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row   # lets us access columns by name, e.g. row["name"]
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def close_db(exception=None):
    """Registered as a Flask teardown handler in app.py — closes the
    per-request connection so SQLite is never left locked between requests."""
    if g is not None:
        conn = g.pop("db_conn", None)
        if conn is not None:
            conn.close()


def init_db():
    """Create all tables from schema.sql if they don't exist yet."""
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    with get_db() as conn, open(schema_path) as f:
        conn.executescript(f.read())


def log_audit(conn, table_name, record_id, field, old_value, new_value, changed_by, reason=None):
    """
    Record a change to something important. Called any time an official
    mark or a student record is corrected after the fact.
    """
    conn.execute(
        "INSERT INTO audit_log (table_name, record_id, field, old_value, new_value, changed_by, reason) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (table_name, record_id, field, str(old_value), str(new_value), changed_by, reason),
    )
