"""
generate_sample_marksheet.py — produces a mark-sheet IMAGE that looks like
what a teacher would scan with a phone, for demo purposes.

Per spec section 5, the layout is designed for machine recognition first:
- one student per line
- Student ID printed first (structured format: 2 letters + 3 digits)
- name second
- a clearly boxed mark field last
- minimal decoration

We deliberately seed a few realistic problems into the demo sheet so
Phase 9 (testing) has real cases to exercise:
  - ST010: mark is smudged/faint -> low OCR confidence -> must be reviewed
  - ST099: an ID that does not exist in this class -> "ID not found"
  - ST015: mark left blank -> "missing mark"
  - ST007: mark written as "twenty-two" style typo (21 -> invalid, out of range... )
"""
from PIL import Image, ImageDraw, ImageFont

WIDTH, HEIGHT = 1000, 1400
LEFT_MARGIN = 60
ROW_HEIGHT = 40
START_Y = 160


def _font(size, bold=False):
    try:
        path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else \
               "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def generate(students, subject_name, class_name, term_name, out_path,
             faint_codes=None, blank_codes=None, unknown_extra_rows=None, max_score=20, component_name=None):
    faint_codes = faint_codes or set()
    blank_codes = blank_codes or set()
    unknown_extra_rows = unknown_extra_rows or []

    img = Image.new("RGB", (WIDTH, HEIGHT), "white")
    draw = ImageDraw.Draw(img)

    title_font = _font(28, bold=True)
    header_font = _font(18, bold=True)
    row_font = _font(22)

    draw.text((LEFT_MARGIN, 30), "SAHIHI STANDARD MARK SHEET", font=title_font, fill="black")
    subtitle = f"Class: {class_name}    Subject: {subject_name}    Term: {term_name}"
    if component_name:
        subtitle += f"    Assessment: {component_name}"
    draw.text((LEFT_MARGIN, 75), subtitle, font=header_font, fill="black")
    draw.text((LEFT_MARGIN, 100), "Instructions: Write clearly. One mark per box. Do not skip rows.",
               font=header_font, fill="gray")

    # Column headers
    y = START_Y - 30
    draw.text((LEFT_MARGIN, y), "Student ID", font=header_font, fill="black")
    draw.text((LEFT_MARGIN + 200, y), "Student Name", font=header_font, fill="black")
    draw.text((LEFT_MARGIN + 620, y), f"Mark /{int(max_score)}", font=header_font, fill="black")
    draw.line([(LEFT_MARGIN, y + 25), (WIDTH - LEFT_MARGIN, y + 25)], fill="black", width=2)

    rows_to_print = list(students) + unknown_extra_rows

    y = START_Y
    for idx, (code, name) in enumerate(rows_to_print):
        fill = "black"
        # Simulate a fixed, deterministic "mark" for reproducibility, scaled to max_score
        mark_value = str(round((8 + (idx * 3) % 13) * (max_score / 20)))

        draw.text((LEFT_MARGIN, y), code, font=row_font, fill="black")
        draw.text((LEFT_MARGIN + 200, y), name, font=row_font, fill="black")

        box = (LEFT_MARGIN + 620, y - 4, LEFT_MARGIN + 700, y + 30)
        draw.rectangle(box, outline="black", width=1)

        if code in blank_codes:
            pass  # leave mark box empty on purpose
        elif code in faint_codes:
            # very light gray text simulates a faint/smudged handwritten mark
            draw.text((LEFT_MARGIN + 632, y), mark_value, font=row_font, fill=(210, 210, 210))
        else:
            draw.text((LEFT_MARGIN + 632, y), mark_value, font=row_font, fill="black")

        y += ROW_HEIGHT

    img.save(out_path)
    return out_path


if __name__ == "__main__":
    from seed_data import seed
    school_id, class_id, term_id, subject_ids, students, component_ids = seed()

    # Build the demo scenario: mostly clean data + a few deliberate problems
    demo_students = students[:20]  # ST001..ST020

    out = generate(
        demo_students,
        subject_name="Mathematics",
        class_name="Form 3A",
        term_name="Term 1",
        out_path="uploads/demo_marksheet_mathematics.png",
        faint_codes={"ST010"},
        blank_codes={"ST015"},
        unknown_extra_rows=[("ST099", "Unknown Student")],
        max_score=20,
        component_name="Sequence 1",
    )
    print("Sample mark sheet written to", out)
