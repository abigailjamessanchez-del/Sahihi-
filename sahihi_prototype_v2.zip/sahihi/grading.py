"""
grading.py — the configurable grading engine.

The whole point of SAHIHI is ONE codebase serving many schools. So every
function here takes a school_id and looks up that school's own grading
scale, subjects, coefficients, and assessment components from the
database. There is no if school == "X" branching anywhere — that would
defeat the purpose.

V2 change: a subject's score for a term is no longer stored directly — it
is DERIVED from that student's marks across all assessment components
(Sequence 1, Sequence 2, Exam, ...), each normalized onto the school's
max_score scale and combined using each component's configured weight.
"""


def get_grade_letter(conn, school_id, score, max_score):
    """
    Convert a raw score into that school's grade letter, using whatever
    grading_scales rows exist for this school. Falls back to 'N/A' if the
    school hasn't configured a scale (better than guessing).
    """
    normalised = (score / max_score) * 100 if max_score else score

    rows = conn.execute(
        "SELECT min_score, max_score, grade_letter, remark FROM grading_scales "
        "WHERE school_id = ? ORDER BY min_score DESC",
        (school_id,),
    ).fetchall()

    if not rows:
        return {"letter": "N/A", "remark": "No grading scale configured"}

    scale_max = max(r["max_score"] for r in rows)
    compare_value = score if abs(scale_max - max_score) < 0.01 else normalised

    for row in rows:
        if row["min_score"] <= compare_value <= row["max_score"]:
            return {"letter": row["grade_letter"], "remark": row["remark"]}
    return {"letter": "N/A", "remark": "Score outside configured scale"}


def compute_subject_term_score(conn, school_id, student_id, subject_id, term_id):
    """
    Combine a student's marks across all assessment components recorded
    for this subject/term into one score on the school's max_score scale.

    Each component mark is normalized (component may be out of a different
    max_score than the school default, e.g. an Exam out of 100 alongside
    Sequences out of 20) then combined using each component's `weight`.
    Only components that actually have a recorded mark are included — a
    missing component simply isn't counted, rather than treated as zero
    (spec: never silently assume a value; a genuinely missing assessment
    is a data-entry gap the school should notice, not a penalty SAHIHI
    invents on its own).

    Returns None if no marks exist yet for this subject/term.
    """
    school = conn.execute("SELECT * FROM schools WHERE id = ?", (school_id,)).fetchone()

    rows = conn.execute(
        """
        SELECT m.score, ac.name AS component_name, ac.weight, ac.max_score AS component_max
        FROM marks m
        JOIN assessment_components ac ON ac.id = m.assessment_component_id
        WHERE m.student_id = ? AND m.subject_id = ? AND m.term_id = ?
        """,
        (student_id, subject_id, term_id),
    ).fetchall()

    if not rows:
        return None

    weighted_total = 0.0
    total_weight = 0.0
    components = []
    for r in rows:
        normalized = (r["score"] / r["component_max"]) * school["max_score"] if r["component_max"] else r["score"]
        weighted_total += normalized * r["weight"]
        total_weight += r["weight"]
        components.append({
            "component": r["component_name"],
            "raw_score": r["score"],
            "component_max": r["component_max"],
        })

    combined = weighted_total / total_weight if total_weight else 0
    return {"score": round(combined, 2), "components": components}


def compute_student_term_summary(conn, school_id, student_id, term_id):
    """
    Pull every subject this student has at least one component mark for
    in this term, derive each subject's combined score, and compute:
      - per-subject grade
      - weighted average (using each subject's coefficient)
      - overall grade + pass/fail
    Returns None if the student has no marks recorded yet for this term.
    """
    school = conn.execute("SELECT * FROM schools WHERE id = ?", (school_id,)).fetchone()

    subject_ids = conn.execute(
        "SELECT DISTINCT s.id, s.name, s.coefficient FROM marks m "
        "JOIN subjects s ON s.id = m.subject_id "
        "WHERE m.student_id = ? AND m.term_id = ?",
        (student_id, term_id),
    ).fetchall()

    if not subject_ids:
        return None

    subject_results = []
    weighted_total = 0.0
    total_coefficient = 0.0

    for subj in subject_ids:
        combined = compute_subject_term_score(conn, school_id, student_id, subj["id"], term_id)
        if combined is None:
            continue
        grade = get_grade_letter(conn, school_id, combined["score"], school["max_score"])
        subject_results.append({
            "subject": subj["name"],
            "score": combined["score"],
            "components": combined["components"],
            "coefficient": subj["coefficient"],
            "grade": grade["letter"],
            "remark": grade["remark"],
        })
        weighted_total += combined["score"] * subj["coefficient"]
        total_coefficient += subj["coefficient"]

    average = weighted_total / total_coefficient if total_coefficient else 0
    overall_grade = get_grade_letter(conn, school_id, average, school["max_score"])
    passed = average >= school["pass_mark"]

    return {
        "subjects": subject_results,
        "average": round(average, 2),
        "overall_grade": overall_grade["letter"],
        "overall_remark": overall_grade["remark"],
        "passed": passed,
    }


def compute_class_ranking(conn, school_id, class_id, term_id):
    """
    Rank every student in a class for a term by weighted average.
    Only meaningful once every student has at least one mark for the term.
    Returns a list ordered best-to-worst with a 'rank' field attached.
    """
    students = conn.execute(
        "SELECT id, student_code, full_name FROM students WHERE class_id = ? AND school_id = ?",
        (class_id, school_id),
    ).fetchall()

    results = []
    for s in students:
        summary = compute_student_term_summary(conn, school_id, s["id"], term_id)
        if summary:
            results.append({
                "student_id": s["id"],
                "student_code": s["student_code"],
                "full_name": s["full_name"],
                "average": summary["average"],
            })

    results.sort(key=lambda x: x["average"], reverse=True)
    for i, r in enumerate(results, start=1):
        r["rank"] = i
    return results
