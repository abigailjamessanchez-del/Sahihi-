"""
ocr.py — turns a photographed/scanned mark sheet image into rows of
(student_id, name, mark) with a confidence score, WITHOUT ever deciding
on its own that the result is correct. That decision always belongs to
a human teacher (see verification workflow in app.py).

IMPORTANT — swap point for production:
`extract_rows_tesseract()` is what actually runs in this prototype, using
local Tesseract OCR. It works fine on clearly printed text but is weak on
real handwriting. In production, replace the body of `extract_rows()`
with a call to Google Cloud Vision / Document AI (or Azure Document
Intelligence), which is built specifically for handwriting and returns
per-field confidence scores the same way this function does. Nothing
else in the app needs to change — every other module only talks to
`extract_rows()`, never to Tesseract directly.
"""
import re
import hashlib
import pytesseract
from PIL import Image

# Below this OCR confidence (0-100), a value is flagged for mandatory review
LOW_CONFIDENCE_THRESHOLD = 75

# Common OCR character confusions. Real handwriting/print recognition
# regularly swaps visually-similar letters and digits (O/0, I/1, S/5...).
# Rather than let a single misread character silently kill a whole row
# (which is worse — the row just vanishes with no error shown), we correct
# for the *expected* character type at each position of the Student ID,
# and let the confidence score — not the character shape — decide whether
# a human needs to double check it.
_LETTER_FIX = {"0": "O", "1": "I", "5": "S", "8": "B", "6": "G", "2": "Z"}
_DIGIT_FIX = {"O": "0", "Q": "0", "D": "0", "I": "1", "L": "1", "S": "5", "B": "8", "G": "6", "Z": "2"}


def file_hash(path):
    """Used to detect the same mark sheet being uploaded twice."""
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def normalize_student_code(raw):
    """
    Student IDs follow a fixed structured format: letters, then digits
    (spec section 5). Knowing that shape lets us correct common OCR
    misreads instead of just failing to match, e.g. 'STOO1' -> 'ST001'.
    """
    if not raw:
        return raw
    s = re.sub(r"[^A-Za-z0-9]", "", raw).upper()
    fixed = []
    for i, ch in enumerate(s):
        if i < 2:  # expect a letter here
            fixed.append(_LETTER_FIX.get(ch, ch))
        else:      # expect a digit here
            fixed.append(_DIGIT_FIX.get(ch, ch))
    return "".join(fixed)


def normalize_mark_token(raw):
    """Apply the same digit-confusion fix to a mark, e.g. 'l3' -> '13'."""
    if not raw:
        return None
    s = re.sub(r"[^A-Za-z0-9.]", "", raw).upper()
    fixed = "".join(_DIGIT_FIX.get(ch, ch) for ch in s)
    return fixed if re.match(r"^\d{1,2}(\.\d)?$", fixed) else None


def extract_rows(image_path, max_score=20):
    """
    Public entry point used by the rest of the app.
    Returns a list of dicts: {row_number, student_code, name, mark, confidence}
    """
    return extract_rows_tesseract(image_path, max_score)


def extract_rows_tesseract(image_path, max_score=20):
    img = Image.open(image_path).convert("L")  # grayscale improves OCR reliability

    # image_to_data gives us per-word bounding boxes + confidence, which we
    # need to flag low-confidence fields individually rather than trusting
    # the whole page equally.
    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)

    # Group words back into lines using Tesseract's line/block numbering,
    # because a mark-sheet row is "ID  Name  Mark" spread across several words.
    lines = {}
    for i in range(len(data["text"])):
        word = data["text"][i].strip()
        conf = float(data["conf"][i])
        if not word or conf < 0:
            continue
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        lines.setdefault(key, {"words": [], "confs": []})
        lines[key]["words"].append(word)
        lines[key]["confs"].append(conf)

    rows = []
    row_number = 0
    header_seen = False

    for key in sorted(lines.keys()):
        words = lines[key]["words"]
        confs = lines[key]["confs"]
        text = " ".join(words)

        # The column-header line ("Student ID  Student Name  Mark /20")
        # marks where the data table starts. Everything before it
        # (title, instructions) is not a data row.
        if not header_seen:
            if "Student" in text and ("ID" in text or "Name" in text):
                header_seen = True
            continue

        if len(words) < 1:
            continue

        row_number += 1
        id_conf = confs[0]
        raw_id = words[0]
        student_code = normalize_student_code(raw_id)

        # The mark is expected to be the last token on the line, if present
        mark_text, mark_conf = None, None
        remainder_words = words[1:]
        if remainder_words:
            candidate = normalize_mark_token(remainder_words[-1])
            if candidate is not None:
                mark_text = candidate
                mark_conf = confs[-1]
                remainder_words = remainder_words[:-1]

        name_text = " ".join(remainder_words) if remainder_words else None

        # Weight overall confidence toward the two fields that matter most
        # (ID and mark) rather than diluting it with high-confidence name text.
        key_confs = [c for c in [id_conf, mark_conf] if c is not None]
        overall_conf = sum(key_confs) / len(key_confs) if key_confs else sum(confs) / len(confs)

        rows.append({
            "row_number": row_number,
            "student_code": student_code,
            "name": name_text,
            "mark": mark_text,
            "confidence": round(overall_conf, 1),
            "low_confidence": overall_conf < LOW_CONFIDENCE_THRESHOLD,
        })

    return rows
