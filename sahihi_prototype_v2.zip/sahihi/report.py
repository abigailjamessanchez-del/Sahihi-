"""
report.py — generates a professional-looking PDF report card.
Content (subjects, grades, ranking) all comes from grading.py, which
already respects each school's own configuration.

V2 change: the subject table now shows the mark for each assessment
component (Sequence 1, Sequence 2, Exam...) alongside the combined score,
so the report card shows its working rather than just a final number.
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

from grading import compute_student_term_summary, compute_class_ranking

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "uploads", "reports")


def generate_report_card(conn, school_id, student_id, term_id):
    os.makedirs(REPORTS_DIR, exist_ok=True)

    school = conn.execute("SELECT * FROM schools WHERE id = ?", (school_id,)).fetchone()
    student = conn.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    class_row = conn.execute("SELECT * FROM classes WHERE id = ?", (student["class_id"],)).fetchone()
    term = conn.execute("SELECT * FROM terms WHERE id = ?", (term_id,)).fetchone()
    year = conn.execute("SELECT * FROM academic_years WHERE id = ?", (term["academic_year_id"],)).fetchone()

    summary = compute_student_term_summary(conn, school_id, student_id, term_id)
    if not summary:
        return None

    # Column set = this school's active assessment components, in the
    # order the admin configured them, so every report card in the school
    # shows the same columns regardless of which subjects a student took.
    # Use each component's short code for the header where available —
    # full names ("Sequence 1") don't fit in a narrow column without
    # overlapping; codes ("SEQ1") do.
    components = conn.execute(
        "SELECT name, code FROM assessment_components WHERE school_id = ? AND is_active = 1 ORDER BY order_index",
        (school_id,),
    ).fetchall()
    component_names = [c["name"] for c in components]
    component_headers = [(c["code"] or c["name"])[:8] for c in components]

    rank_info = None
    if school["ranking_enabled"]:
        ranking = compute_class_ranking(conn, school_id, student["class_id"], term_id)
        for r in ranking:
            if r["student_id"] == student_id:
                rank_info = f'{r["rank"]} / {len(ranking)}'
                break

    out_path = os.path.join(REPORTS_DIR, f"report_{student['student_code']}_{term_id}.pdf")

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("title", parent=styles["Heading1"], alignment=1, fontSize=18)
    sub_style = ParagraphStyle("sub", parent=styles["Normal"], alignment=1, fontSize=11)

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                             topMargin=20 * mm, bottomMargin=20 * mm)
    elements = []

    if school["logo_path"] and os.path.exists(school["logo_path"]):
        try:
            elements.append(Image(school["logo_path"], width=20 * mm, height=20 * mm))
            elements.append(Spacer(1, 2 * mm))
        except Exception:
            pass  # a broken/unsupported logo file should never block report generation

    elements.append(Paragraph(school["name"], title_style))
    elements.append(Paragraph(f"Academic Year {year['label']} &mdash; {term['name']} Report Card", sub_style))
    if school["address"]:
        elements.append(Paragraph(school["address"], sub_style))
    elements.append(Spacer(1, 10 * mm))

    info_data = [
        ["Student Name:", student["full_name"], "Student ID:", student["student_code"]],
        ["Class:", class_row["name"], "Term:", term["name"]],
    ]
    info_table = Table(info_data, colWidths=[80 * mm, 55 * mm, 30 * mm, 25 * mm])
    info_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(info_table)
    elements.append(Spacer(1, 8 * mm))

    header = ["Subject"] + component_headers + [f"Term/{school['max_score']:.0f}", "Coef", "Grade", "Remark"]
    table_data = [header]
    for s in summary["subjects"]:
        by_component = {c["component"]: c["raw_score"] for c in s["components"]}
        row = [s["subject"]] + [
            (f'{by_component[name]:.1f}' if name in by_component else "-") for name in component_names
        ]
        row += [f'{s["score"]:.1f}', f'{s["coefficient"]:.0f}', s["grade"], s["remark"]]
        table_data.append(row)

    n_components = len(component_names)
    subject_w = 34 * mm
    component_w = 16 * mm
    term_w, coef_w, grade_w = 20 * mm, 14 * mm, 16 * mm
    remark_w = max(20 * mm, 175 * mm - subject_w - n_components * component_w - term_w - coef_w - grade_w)
    col_widths = [subject_w] + [component_w] * n_components + [term_w, coef_w, grade_w, remark_w]

    subj_table = Table(table_data, colWidths=col_widths)
    subj_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f2f2")]),
    ]))
    elements.append(subj_table)
    elements.append(Spacer(1, 8 * mm))

    summary_data = [
        ["Weighted Average:", f'{summary["average"]:.2f} / {school["max_score"]:.0f}'],
        ["Overall Grade:", f'{summary["overall_grade"]} ({summary["overall_remark"]})'],
        ["Result:", "PASS" if summary["passed"] else "FAIL"],
    ]
    if rank_info:
        summary_data.append(["Class Rank:", rank_info])

    summary_table = Table(summary_data, colWidths=[60 * mm, 100 * mm])
    summary_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(summary_table)

    doc.build(elements)
    return out_path
