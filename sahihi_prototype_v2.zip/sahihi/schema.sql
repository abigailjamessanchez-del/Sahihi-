-- SAHIHI database schema
-- Design principle: nothing school-specific is hard-coded. A "school" row plus
-- its grading_scale/subjects/classes rows fully determine how that school's
-- marks are calculated and how its report card looks.

CREATE TABLE IF NOT EXISTS schools (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT,
    contact_info TEXT,
    logo_path TEXT,
    max_score REAL NOT NULL DEFAULT 20,      -- e.g. marks out of 20
    ranking_enabled INTEGER NOT NULL DEFAULT 1,
    pass_mark REAL NOT NULL DEFAULT 10
);

-- Configurable grading scale per school (e.g. 16-20 = A, 14-15.9 = B, ...)
CREATE TABLE IF NOT EXISTS grading_scales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    min_score REAL NOT NULL,
    max_score REAL NOT NULL,
    grade_letter TEXT NOT NULL,
    remark TEXT
);

CREATE TABLE IF NOT EXISTS academic_years (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    label TEXT NOT NULL              -- e.g. "2025/2026"
);

CREATE TABLE IF NOT EXISTS terms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    academic_year_id INTEGER NOT NULL REFERENCES academic_years(id),
    name TEXT NOT NULL               -- e.g. "Term 1"
);

CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    name TEXT NOT NULL               -- e.g. "Form 3A"
);

CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    name TEXT NOT NULL,
    code TEXT,
    coefficient REAL NOT NULL DEFAULT 1
);

-- Assessment components (Sequence 1, Sequence 2, Exam, Project...) are
-- configured per school, NOT hard-coded. A subject's final term score is
-- computed by combining the marks recorded against each of these, weighted
-- by `weight` and normalized onto the school's max_score scale (a
-- component doesn't have to share the school's /20 or /100 — e.g. an exam
-- marked out of 100 while sequences are out of 20 both normalize cleanly).
CREATE TABLE IF NOT EXISTS assessment_components (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    name TEXT NOT NULL,              -- e.g. "Sequence 1"
    code TEXT,                       -- e.g. "SEQ1"
    weight REAL NOT NULL DEFAULT 1,  -- relative contribution to the term score
    max_score REAL NOT NULL DEFAULT 20,
    order_index INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('teacher','admin'))
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    student_code TEXT NOT NULL UNIQUE,   -- primary identifier, e.g. ST001
    full_name TEXT NOT NULL,
    class_id INTEGER NOT NULL REFERENCES classes(id)
);

-- One row per uploaded/scanned mark sheet (a batch). A mark sheet is
-- specific to one class + subject + term + assessment component — e.g.
-- "Form 3A, Mathematics, Term 1, Sequence 1" is one sheet; "...Sequence 2"
-- is a separate sheet, scanned and reviewed independently.
CREATE TABLE IF NOT EXISTS mark_sheets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL REFERENCES schools(id),
    class_id INTEGER NOT NULL REFERENCES classes(id),
    subject_id INTEGER NOT NULL REFERENCES subjects(id),
    term_id INTEGER NOT NULL REFERENCES terms(id),
    assessment_component_id INTEGER NOT NULL REFERENCES assessment_components(id),
    teacher_id INTEGER NOT NULL REFERENCES users(id),
    image_path TEXT NOT NULL,
    image_hash TEXT NOT NULL,            -- for duplicate-upload detection
    status TEXT NOT NULL DEFAULT 'pending_review',  -- pending_review, saved, rejected
    uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- One row per detected line item on a mark sheet, before it becomes an official mark
CREATE TABLE IF NOT EXISTS detected_rows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mark_sheet_id INTEGER NOT NULL REFERENCES mark_sheets(id),
    row_number INTEGER NOT NULL,
    detected_student_code TEXT,
    detected_name TEXT,
    detected_mark TEXT,
    confidence REAL,                     -- 0-100, from OCR engine
    matched_student_id INTEGER REFERENCES students(id),
    match_status TEXT,                   -- ok, id_not_found, name_mismatch, invalid_mark, missing_mark
    final_student_id INTEGER REFERENCES students(id),
    final_mark REAL,
    review_status TEXT NOT NULL DEFAULT 'pending',  -- pending, confirmed, edited, rejected
    reviewed_by INTEGER REFERENCES users(id),
    reviewed_at TEXT
);

-- Official, saved marks (only created once a detected_row is confirmed).
-- One mark per student/subject/term/assessment-component — e.g. Sequence 1
-- and Sequence 2 are two separate rows here. SAHIHI computes the combined
-- term score for the subject from all of a student's component marks
-- (see grading.compute_subject_term_score) — nowhere is a single
-- "term score" stored directly; it's always derived.
CREATE TABLE IF NOT EXISTS marks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id),
    subject_id INTEGER NOT NULL REFERENCES subjects(id),
    term_id INTEGER NOT NULL REFERENCES terms(id),
    assessment_component_id INTEGER NOT NULL REFERENCES assessment_components(id),
    score REAL NOT NULL,
    source_mark_sheet_id INTEGER REFERENCES mark_sheets(id),
    source_detected_row_id INTEGER REFERENCES detected_rows(id),
    entered_by INTEGER NOT NULL REFERENCES users(id),
    entered_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(student_id, subject_id, term_id, assessment_component_id)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_name TEXT NOT NULL,
    record_id INTEGER NOT NULL,
    field TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    changed_by INTEGER REFERENCES users(id),
    changed_at TEXT NOT NULL DEFAULT (datetime('now')),
    reason TEXT
);
