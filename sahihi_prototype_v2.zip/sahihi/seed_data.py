"""
seed_data.py — sets up ONE example school configuration (per spec section 4)
and ~25 fictional students, so the demo has something real to scan into.

Run this once: `python3 seed_data.py`
"""
import os
from werkzeug.security import generate_password_hash
from db import get_db, init_db, DB_PATH

FIRST_NAMES = ["Abigail", "Brian", "Carine", "Divine", "Eric", "Farida", "Gilbert",
               "Hilda", "Ivan", "Joyce", "Kevin", "Lea", "Marcel", "Nadia", "Oscar",
               "Patricia", "Quentin", "Rita", "Samuel", "Theresa", "Ulrich", "Vivian",
               "Walter", "Yvonne", "Zita"]
LAST_NAMES = ["James", "Mbeki", "Fonka", "Ngu", "Tabi", "Achu", "Nkemta", "Besong",
              "Ekwa", "Fru"]


def seed():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)  # fresh demo DB every time this script runs
    init_db()

    with get_db() as conn:
        # --- one example school ---------------------------------------
        cur = conn.execute(
            "INSERT INTO schools (name, max_score, ranking_enabled, pass_mark) VALUES (?, ?, ?, ?)",
            ("Kilimani Secondary School", 20, 1, 10),
        )
        school_id = cur.lastrowid

        # Configurable grading scale for THIS school (marks out of 20)
        scale = [
            (16, 20, "A", "Excellent"),
            (14, 15.99, "B", "Very Good"),
            (12, 13.99, "C", "Good"),
            (10, 11.99, "D", "Pass"),
            (0, 9.99, "F", "Fail"),
        ]
        for min_s, max_s, letter, remark in scale:
            conn.execute(
                "INSERT INTO grading_scales (school_id, min_score, max_score, grade_letter, remark) "
                "VALUES (?, ?, ?, ?, ?)",
                (school_id, min_s, max_s, letter, remark),
            )

        year_id = conn.execute(
            "INSERT INTO academic_years (school_id, label) VALUES (?, ?)",
            (school_id, "2025/2026"),
        ).lastrowid

        term_id = conn.execute(
            "INSERT INTO terms (school_id, academic_year_id, name) VALUES (?, ?, ?)",
            (school_id, year_id, "Term 1"),
        ).lastrowid

        class_id = conn.execute(
            "INSERT INTO classes (school_id, name) VALUES (?, ?)",
            (school_id, "Form 3A"),
        ).lastrowid

        subject_defs = [("Mathematics", 4), ("English", 4), ("Biology", 3), ("Chemistry", 3)]
        subject_ids = {}
        for name, coef in subject_defs:
            sid = conn.execute(
                "INSERT INTO subjects (school_id, name, coefficient) VALUES (?, ?, ?)",
                (school_id, name, coef),
            ).lastrowid
            subject_ids[name] = sid

        # Assessment components — configurable, not hard-coded (spec V2 section 2/3D).
        # Sequences carry weight 1 each; the Exam counts double and is marked
        # out of 100 to prove components can use a different scale than the school's.
        component_defs = [("Sequence 1", "SEQ1", 1, 20), ("Sequence 2", "SEQ2", 1, 20), ("Exam", "EXAM", 2, 100)]
        component_ids = {}
        for i, (name, code, weight, max_score) in enumerate(component_defs):
            cid = conn.execute(
                "INSERT INTO assessment_components (school_id, name, code, weight, max_score, order_index) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (school_id, name, code, weight, max_score, i),
            ).lastrowid
            component_ids[name] = cid

        # --- users -------------------------------------------------------
        conn.execute(
            "INSERT INTO users (school_id, username, password_hash, full_name, role) VALUES (?, ?, ?, ?, ?)",
            (school_id, "teacher1", generate_password_hash("teacher123"), "Mr. Ngu Peter", "teacher"),
        )
        conn.execute(
            "INSERT INTO users (school_id, username, password_hash, full_name, role) VALUES (?, ?, ?, ?, ?)",
            (school_id, "admin1", generate_password_hash("admin123"), "Mrs. Achu Grace", "admin"),
        )

        # --- ~25 fictional students ---------------------------------------
        students = []
        for i in range(1, 26):
            code = f"ST{i:03d}"
            name = f"{FIRST_NAMES[i - 1]} {LAST_NAMES[i % len(LAST_NAMES)]}"
            conn.execute(
                "INSERT INTO students (school_id, student_code, full_name, class_id) VALUES (?, ?, ?, ?)",
                (school_id, code, name, class_id),
            )
            students.append((code, name))

        conn.commit()

        print(f"Seeded school_id={school_id}, class_id={class_id}, term_id={term_id}")
        print("Subjects:", subject_ids)
        print("Assessment components:", component_ids)
        print(f"{len(students)} students created (ST001..ST025)")
        print("Login: teacher1 / teacher123   or   admin1 / admin123")

    return school_id, class_id, term_id, subject_ids, students, component_ids


if __name__ == "__main__":
    seed()
