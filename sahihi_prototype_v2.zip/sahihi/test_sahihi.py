"""
test_sahihi.py — Phase 9 automated tests (V2: assessment components).

Run with: python3 -m pytest test_sahihi.py -v
(or: python3 test_sahihi.py)

Uses a throwaway test database so it never touches instance/sahihi.db.
"""
import os
import io
import unittest
import tempfile

os.environ["SAHIHI_TEST"] = "1"

import db as db_module

# Redirect the DB path to a temp file BEFORE importing app/grading/report,
# since they hold a module-level reference to db.DB_PATH indirectly via get_db().
TEST_DB_FD, TEST_DB_PATH = tempfile.mkstemp(suffix=".db")
db_module.DB_PATH = TEST_DB_PATH

import app as app_module          # noqa: E402
import grading                    # noqa: E402
import ocr                        # noqa: E402
from generate_sample_marksheet import generate  # noqa: E402
from werkzeug.security import generate_password_hash  # noqa: E402


def build_test_school():
    if os.path.exists(TEST_DB_PATH):
        os.remove(TEST_DB_PATH)
    db_module.init_db()
    conn = db_module.get_db()
    school_id = conn.execute(
        "INSERT INTO schools (name, max_score, ranking_enabled, pass_mark) VALUES (?,?,?,?)",
        ("Test School", 20, 1, 10)).lastrowid
    for mn, mx, letter, remark in [(16, 20, "A", "Excellent"), (14, 15.99, "B", "Very Good"),
                                    (12, 13.99, "C", "Good"), (10, 11.99, "D", "Pass"), (0, 9.99, "F", "Fail")]:
        conn.execute("INSERT INTO grading_scales (school_id, min_score, max_score, grade_letter, remark) "
                     "VALUES (?,?,?,?,?)", (school_id, mn, mx, letter, remark))
    year_id = conn.execute("INSERT INTO academic_years (school_id, label) VALUES (?,?)",
                            (school_id, "2025/2026")).lastrowid
    term_id = conn.execute("INSERT INTO terms (school_id, academic_year_id, name) VALUES (?,?,?)",
                            (school_id, year_id, "Term 1")).lastrowid
    class_id = conn.execute("INSERT INTO classes (school_id, name) VALUES (?,?)",
                             (school_id, "Test Class")).lastrowid
    subject_id = conn.execute("INSERT INTO subjects (school_id, name, coefficient) VALUES (?,?,?)",
                               (school_id, "Mathematics", 4)).lastrowid
    teacher_id = conn.execute(
        "INSERT INTO users (school_id, username, password_hash, full_name, role) VALUES (?,?,?,?,?)",
        (school_id, "t1", generate_password_hash("pw"), "Test Teacher", "teacher")).lastrowid
    admin_id = conn.execute(
        "INSERT INTO users (school_id, username, password_hash, full_name, role) VALUES (?,?,?,?,?)",
        (school_id, "a1", generate_password_hash("pw"), "Test Admin", "admin")).lastrowid

    # Two assessment components with different weights and different
    # max_scores — this is the central V2 feature under test.
    seq1_id = conn.execute(
        "INSERT INTO assessment_components (school_id, name, code, weight, max_score, order_index) "
        "VALUES (?,?,?,?,?,?)", (school_id, "Sequence 1", "SEQ1", 1, 20, 0)).lastrowid
    seq2_id = conn.execute(
        "INSERT INTO assessment_components (school_id, name, code, weight, max_score, order_index) "
        "VALUES (?,?,?,?,?,?)", (school_id, "Sequence 2", "SEQ2", 1, 20, 1)).lastrowid
    exam_id = conn.execute(
        "INSERT INTO assessment_components (school_id, name, code, weight, max_score, order_index) "
        "VALUES (?,?,?,?,?,?)", (school_id, "Exam", "EXAM", 2, 100, 2)).lastrowid

    students = []
    names = ["Amara Okoye", "Baraka Mensah", "Chidi Obi", "Deka Sango", "Efua Boateng"]
    for i in range(1, 6):
        code = f"ST{i:03d}"
        sid = conn.execute("INSERT INTO students (school_id, student_code, full_name, class_id) VALUES (?,?,?,?)",
                            (school_id, code, names[i - 1], class_id)).lastrowid
        students.append((sid, code, names[i - 1]))
    conn.commit()
    conn.close()
    return dict(school_id=school_id, term_id=term_id, class_id=class_id,
                subject_id=subject_id, teacher_id=teacher_id, admin_id=admin_id, students=students,
                seq1_id=seq1_id, seq2_id=seq2_id, exam_id=exam_id)


class GradingTests(unittest.TestCase):
    def setUp(self):
        self.ctx = build_test_school()
        self.conn = db_module.get_db()

    def tearDown(self):
        self.conn.close()

    def test_grade_boundaries(self):
        cases = [(20, "A"), (16, "A"), (15.99, "B"), (14, "B"), (12, "C"), (10, "D"), (9.99, "F"), (0, "F")]
        for score, expected in cases:
            result = grading.get_grade_letter(self.conn, self.ctx["school_id"], score, 20)
            self.assertEqual(result["letter"], expected, f"score {score} should be {expected}")

    def test_configurable_scales_are_independent(self):
        """Two schools with different scales must grade the same % differently — proves no hard-coding."""
        conn = self.conn
        school2 = conn.execute(
            "INSERT INTO schools (name, max_score, ranking_enabled, pass_mark) VALUES (?,?,?,?)",
            ("Other School", 100, 1, 50)).lastrowid
        conn.execute("INSERT INTO grading_scales (school_id, min_score, max_score, grade_letter, remark) "
                     "VALUES (?,?,?,?,?)", (school2, 0, 100, "Z", "Everyone passes"))
        conn.commit()
        g1 = grading.get_grade_letter(conn, self.ctx["school_id"], 5, 20)   # 25%
        g2 = grading.get_grade_letter(conn, school2, 25, 100)              # 25%
        self.assertNotEqual(g1["letter"], g2["letter"])

    def test_subject_score_combines_weighted_components(self):
        """
        The core V2 requirement: Sequence 1 = 16, Sequence 2 = 18 are two
        separate marks, and SAHIHI must derive the combined subject score
        itself — nothing stores "the term score" directly.
        """
        conn = self.conn
        ctx = self.ctx
        sid = ctx["students"][0][0]
        conn.execute("INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                     "entered_by) VALUES (?,?,?,?,?,?)",
                     (sid, ctx["subject_id"], ctx["term_id"], ctx["seq1_id"], 16, ctx["teacher_id"]))
        conn.execute("INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                     "entered_by) VALUES (?,?,?,?,?,?)",
                     (sid, ctx["subject_id"], ctx["term_id"], ctx["seq2_id"], 18, ctx["teacher_id"]))
        conn.commit()

        # Both components have weight 1 and are already on the school's /20
        # scale, so the combined score is a plain average: (16+18)/2 = 17.
        result = grading.compute_subject_term_score(conn, ctx["school_id"], sid, ctx["subject_id"], ctx["term_id"])
        self.assertAlmostEqual(result["score"], 17.0)
        self.assertEqual(len(result["components"]), 2)

    def test_subject_score_normalizes_different_max_scores(self):
        """Exam is out of 100 with weight 2 while Sequences are out of 20 weight 1 — must normalize before combining."""
        conn = self.conn
        ctx = self.ctx
        sid = ctx["students"][1][0]
        conn.execute("INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                     "entered_by) VALUES (?,?,?,?,?,?)",
                     (sid, ctx["subject_id"], ctx["term_id"], ctx["seq1_id"], 10, ctx["teacher_id"]))   # 10/20
        conn.execute("INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                     "entered_by) VALUES (?,?,?,?,?,?)",
                     (sid, ctx["subject_id"], ctx["term_id"], ctx["exam_id"], 80, ctx["teacher_id"]))   # 80/100 -> 16/20
        conn.commit()
        # Weighted: (10*1 + 16*2) / (1+2) = 42/3 = 14
        result = grading.compute_subject_term_score(conn, ctx["school_id"], sid, ctx["subject_id"], ctx["term_id"])
        self.assertAlmostEqual(result["score"], 14.0)

    def test_missing_component_not_treated_as_zero(self):
        """Only recorded components count — a not-yet-entered Exam must not silently drag the average to zero."""
        conn = self.conn
        ctx = self.ctx
        sid = ctx["students"][2][0]
        conn.execute("INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                     "entered_by) VALUES (?,?,?,?,?,?)",
                     (sid, ctx["subject_id"], ctx["term_id"], ctx["seq1_id"], 18, ctx["teacher_id"]))
        conn.commit()
        result = grading.compute_subject_term_score(conn, ctx["school_id"], sid, ctx["subject_id"], ctx["term_id"])
        self.assertAlmostEqual(result["score"], 18.0)  # not (18+0+0)/3

    def test_weighted_average_and_ranking(self):
        conn = self.conn
        sid1, sid2 = self.ctx["students"][0][0], self.ctx["students"][1][0]
        conn.execute("INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                     "entered_by) VALUES (?,?,?,?,?,?)",
                     (sid1, self.ctx["subject_id"], self.ctx["term_id"], self.ctx["seq1_id"], 18, self.ctx["teacher_id"]))
        conn.execute("INSERT INTO marks (student_id, subject_id, term_id, assessment_component_id, score, "
                     "entered_by) VALUES (?,?,?,?,?,?)",
                     (sid2, self.ctx["subject_id"], self.ctx["term_id"], self.ctx["seq1_id"], 10, self.ctx["teacher_id"]))
        conn.commit()
        ranking = grading.compute_class_ranking(conn, self.ctx["school_id"], self.ctx["class_id"], self.ctx["term_id"])
        self.assertEqual(ranking[0]["student_id"], sid1)  # higher score ranks first
        self.assertEqual(ranking[0]["rank"], 1)
        self.assertEqual(ranking[1]["rank"], 2)


class OCRTests(unittest.TestCase):
    def test_extract_rows_flags_all_error_cases(self):
        names = ["Amara Okoye", "Baraka Mensah", "Chidi Obi", "Deka Sango", "Efua Boateng",
                 "Farai Dube", "Grace Osei", "Halima Diallo", "Idris Toure", "Jelani Kamau"]
        students = [(f"ST{i:03d}", names[i - 1]) for i in range(1, 11)]
        path = os.path.join(tempfile.gettempdir(), "test_sheet.png")
        generate(students, "Mathematics", "Test Class", "Term 1", path,
                 faint_codes={"ST003"}, blank_codes={"ST005"},
                 unknown_extra_rows=[("ST999", "Ghost Student")])
        rows = ocr.extract_rows(path, max_score=20)
        self.assertEqual(len(rows), 11)  # 10 real students + 1 unknown row — nothing silently dropped

        by_code = {r["student_code"]: r for r in rows}
        self.assertIsNone(by_code["ST005"]["mark"])          # truly blank mark caught
        self.assertTrue(by_code["ST003"]["low_confidence"])  # faint mark flagged for review
        self.assertIn("ST999", by_code)                      # unknown ID still surfaced, not dropped

    def test_id_normalization_fixes_common_misreads(self):
        self.assertEqual(ocr.normalize_student_code("STOO1"), "ST001")
        self.assertEqual(ocr.normalize_student_code("st0O5"), "ST005")

    def test_duplicate_file_hash_detection(self):
        students = [("ST001", "A Student")]
        path1 = os.path.join(tempfile.gettempdir(), "dup1.png")
        path2 = os.path.join(tempfile.gettempdir(), "dup2.png")
        generate(students, "Mathematics", "Test Class", "Term 1", path1)
        generate(students, "Mathematics", "Test Class", "Term 1", path2)
        self.assertEqual(ocr.file_hash(path1), ocr.file_hash(path2))  # identical content -> identical hash


class WebFlowTests(unittest.TestCase):
    """End-to-end tests through the actual Flask routes."""

    def setUp(self):
        self.ctx = build_test_school()
        app_module.app.config["TESTING"] = True
        self.client = app_module.app.test_client()
        self.client.post("/login", data={"username": "t1", "password": "pw"})

    def test_login_required_redirects(self):
        c2 = app_module.app.test_client()
        resp = c2.get("/dashboard")
        self.assertEqual(resp.status_code, 302)

    def test_wrong_password_rejected(self):
        c2 = app_module.app.test_client()
        resp = c2.post("/login", data={"username": "t1", "password": "wrong"})
        self.assertIn(b"Incorrect username or password", resp.data)

    def _scan_and_finalize(self, ctx, component_id, filename_suffix, max_score=20):
        students = [(code, name) for _, code, name in ctx["students"]]
        path = os.path.join(tempfile.gettempdir(), f"flow_sheet_{filename_suffix}.png")
        generate(students, "Mathematics", "Test Class", "Term 1", path, max_score=max_score)

        with open(path, "rb") as f:
            resp = self.client.post("/scan", data={
                "class_id": ctx["class_id"], "subject_id": ctx["subject_id"], "term_id": ctx["term_id"],
                "assessment_component_id": component_id,
                "marksheet_image": (io.BytesIO(f.read()), f"flow_{filename_suffix}.png"),
            }, content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 302, resp.headers.get("Location"))
        sheet_id = int(resp.headers["Location"].rstrip("/").split("/")[-1])

        conn = db_module.get_db()
        rows = conn.execute("SELECT * FROM detected_rows WHERE mark_sheet_id = ?", (sheet_id,)).fetchall()
        self.assertEqual(len(rows), len(students))

        for row in rows:
            self.client.post(f"/verify/{sheet_id}/row/{row['id']}", data={
                "action": "confirm", "student_id": row["matched_student_id"], "mark": row["final_mark"],
            })

        resp = self.client.post(f"/verify/{sheet_id}/finalize")
        self.assertEqual(resp.status_code, 302)
        return sheet_id

    def test_full_scan_to_report_card_flow_with_two_components(self):
        """
        The full V2 demo scenario: scan Sequence 1, scan Sequence 2 as a
        SEPARATE sheet, confirm both are stored as distinct marks, then
        confirm the report card shows a derived combined score.
        """
        ctx = self.ctx
        self._scan_and_finalize(ctx, ctx["seq1_id"], "seq1")
        self._scan_and_finalize(ctx, ctx["seq2_id"], "seq2")

        conn = db_module.get_db()
        marks = conn.execute("SELECT * FROM marks WHERE term_id = ?", (ctx["term_id"],)).fetchall()
        # 5 students x 2 components = 10 separate mark rows, not one overwritten value
        self.assertEqual(len(marks), 10)

        student_id = ctx["students"][0][0]
        resp = self.client.get(f"/report_card/{student_id}/{ctx['term_id']}")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.content_type, "application/pdf")

    def test_out_of_range_mark_rejected_by_api(self):
        ctx = self.ctx
        students = [(code, name) for _, code, name in ctx["students"]]
        path = os.path.join(tempfile.gettempdir(), "range_sheet.png")
        generate(students, "Mathematics", "Test Class", "Term 1", path)
        with open(path, "rb") as f:
            resp = self.client.post("/scan", data={
                "class_id": ctx["class_id"], "subject_id": ctx["subject_id"], "term_id": ctx["term_id"],
                "assessment_component_id": ctx["seq1_id"],
                "marksheet_image": (io.BytesIO(f.read()), "range_sheet.png"),
            }, content_type="multipart/form-data")
        sheet_id = int(resp.headers["Location"].rstrip("/").split("/")[-1])
        conn = db_module.get_db()
        row = conn.execute("SELECT * FROM detected_rows WHERE mark_sheet_id = ? LIMIT 1", (sheet_id,)).fetchone()

        resp = self.client.post(f"/verify/{sheet_id}/row/{row['id']}",
                                 data={"action": "confirm", "student_id": row["matched_student_id"], "mark": 999})
        self.assertEqual(resp.status_code, 400)


class AdminConfigTests(unittest.TestCase):
    """Tests for the School Configuration admin section (spec section 3)."""

    def setUp(self):
        self.ctx = build_test_school()
        app_module.app.config["TESTING"] = True
        self.client = app_module.app.test_client()

    def test_teacher_cannot_access_admin(self):
        self.client.post("/login", data={"username": "t1", "password": "pw"})
        resp = self.client.get("/admin/components")
        self.assertEqual(resp.status_code, 403)

    def test_admin_can_add_assessment_component(self):
        self.client.post("/login", data={"username": "a1", "password": "pw"})
        resp = self.client.post("/admin/components", data={
            "name": "Project", "code": "PROJ", "weight": "1", "max_score": "20",
        })
        self.assertEqual(resp.status_code, 302)
        conn = db_module.get_db()
        row = conn.execute("SELECT * FROM assessment_components WHERE school_id = ? AND name = 'Project'",
                            (self.ctx["school_id"],)).fetchone()
        self.assertIsNotNone(row)

    def test_admin_can_add_subject_and_it_appears_for_scanning(self):
        self.client.post("/login", data={"username": "a1", "password": "pw"})
        resp = self.client.post("/admin/subjects", data={"name": "Geography", "code": "GEO", "coefficient": "2"})
        self.assertEqual(resp.status_code, 302)
        conn = db_module.get_db()
        row = conn.execute("SELECT * FROM subjects WHERE school_id = ? AND name = 'Geography'",
                            (self.ctx["school_id"],)).fetchone()
        self.assertEqual(row["coefficient"], 2.0)

    def test_admin_can_update_grading_scale(self):
        self.client.post("/login", data={"username": "a1", "password": "pw"})
        resp = self.client.post("/admin/grading", data={
            "min_score": "18", "max_score": "20", "grade_letter": "A+", "remark": "Outstanding",
        })
        self.assertEqual(resp.status_code, 302)
        conn = db_module.get_db()
        row = conn.execute("SELECT * FROM grading_scales WHERE school_id = ? AND grade_letter = 'A+'",
                            (self.ctx["school_id"],)).fetchone()
        self.assertIsNotNone(row)


if __name__ == "__main__":
    unittest.main()
